<?php

$input = file_get_contents('php://input');
$input = json_decode($input);

include_once('tokens.php');

function check_user($email,$password){
$token = false;

$conn = new mysqli("localhost","root","ubuntu","users");
if($conn->connect_error){ return ("Connection failed");}

$email = filter_var($email, FILTER_VALIDATE_EMAIL );
if($email===FALSE){
	return 'Please provide a valid email address!';
}

$stmt = $conn->prepare('SELECT * FROM users WHERE email = ? and password = ?');
$stmt->bind_param('ss',$email,$password);
$stmt->execute();
$result = $stmt->get_result();

if($result->num_rows > 0){
	$token = generate_token('myapp');
}

$conn->close();
return $token;
}



if($input->mode=="check_user"){
	$response = check_user($input->email,$input->password);
}

if($input->mode=="create_post"){
$response = "You have to be logged in first!";
	if(check_token($input->token)===TRUE){
	$response= 'Creating post '.$input->content;
}

}



echo json_encode($response);


?>